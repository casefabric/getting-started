"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const planitem_1 = __importDefault(require("../../cmmn/planitem"));
const path_1 = __importDefault(require("../../service/case/path"));
class StateAssertion {
    constructor(path, expectedState) {
        this.expectedState = expectedState;
        if (path instanceof planitem_1.default) {
            this.identifier = path_1.default.from(path.id);
        }
        else {
            this.identifier = path_1.default.from(path);
        }
    }
    run(item) {
        if (!this.expectedState.is(item.currentState)) {
            throw new Error(`Expected plan item "${this.identifier}" in state ${this.expectedState} but found it in state ${item.currentState}`);
        }
    }
    toString() {
        return `"${this.identifier}.currentState === ${this.expectedState}"`;
    }
}
exports.default = StateAssertion;
