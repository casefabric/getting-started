"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const caseservice_1 = __importDefault(require("../../service/case/caseservice"));
const path_1 = __importStar(require("../../service/case/path"));
const time_1 = require("../time");
const stateassertion_1 = __importDefault(require("./stateassertion"));
/**
 * CaseAssertions enables building a hierarchy of a case with it's sub cases, and setting multiple assertions on the case and it's subcases.
 * When assertions are available, we call the runAssertions() method, which will poll until all assertions are true, or give timeout.
 */
class CaseAssertions {
    static from(user, caseInstance) {
        return new CaseAssertions(user, caseInstance);
    }
    constructor(user, item, identifier, parentCase) {
        this.user = user;
        this.identifier = identifier;
        this.parentCase = parentCase;
        this.stateAssertions = [];
        this.subCaseAssertions = [];
        this.id = item === null || item === void 0 ? void 0 : item.id;
        this.caseInstance = item;
        console.log("Putting identifier " + identifier + " and case instance " + (item === null || item === void 0 ? void 0 : item.printPlan()) + " in paren tcase  " + parentCase);
        if (!this.identifier && item)
            this.identifier = new path_1.Identifier(item === null || item === void 0 ? void 0 : item.caseName);
    }
    get items() {
        var _a;
        return ((_a = this.caseInstance) === null || _a === void 0 ? void 0 : _a.planitems) || [];
    }
    /**
     * Shortcut to retrieving a plan item from the most recently fetched case instance.
     * If the case instance has not been fetched, this will throw an error.
     */
    findItem(path, msg) {
        if (!msg) {
            msg = 'No case instance available to search for ' + path;
        }
        if (!this.caseInstance) {
            throw new Error(msg);
        }
        return this.caseInstance.findItem(path);
    }
    /**
     * If the case has a CaseTask, this method can be used to create assertions on the sub case implementing the CaseTask.
     * Note: when the assertions of the main case are ran, this will implicitly assert that the sub case exists.
     */
    assertSubCase(path) {
        const assertion = new CaseAssertions(this.user, undefined, path_1.default.from(path), this);
        this.subCaseAssertions.push(assertion);
        return assertion;
    }
    /**
     * Add an assertion on the plan item with the specified path to have the expected state
     */
    assertPlanItemState(path, expectedState) {
        const identifier = path_1.default.from(path);
        const stateAsserter = this.stateAssertions.find(a => a.identifier.is(identifier)) || new stateassertion_1.default(identifier, expectedState);
        if (this.stateAssertions.indexOf(stateAsserter) < 0) {
            this.stateAssertions.push(stateAsserter);
        }
        stateAsserter.expectedState = expectedState;
        return stateAsserter;
    }
    /**
     * Asynchronously fetch case instance(s) and run all assertions until they succeed.
     */
    runAssertions() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.id && !this.parentCase) {
                throw new Error('Cannot run assertions because case id and parent case are not present on idenfitier ' + this.identifier);
            }
            // Make sure we can read the identifier of the subcase from our parent case instance
            if (this.parentCase && !this.parentCase.caseInstance) {
                yield this.parentCase.refreshCaseInstance();
            }
            // If we only have the identifier, we should lookup our case id in the parent case
            if (!this.id && this.parentCase && this.identifier) {
                this.id = this.parentCase.findItem(this.identifier, `Cannot run assertions because the sub case with identifier ${this.identifier} is not present`).id;
            }
            // Now parallelly call run() on ourselves, and runAssertions() on our subcases
            yield Promise.all([this.run(), ...this.subCaseAssertions.map(subCase => subCase.runAssertions())]);
        });
    }
    refreshCaseInstance() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.id) {
                const caseId = this.id;
                this.caseInstance = yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () { return caseservice_1.default.getCase(this.user, caseId); }));
            }
            else {
                throw new Error(`Cannot run assertions, as we do not have an id on case instance ${this.id} / ${this.identifier}`);
            }
            if (!this.caseInstance) {
                throw new Error(`Unexpectedly failing to refresh case instance ${this.id} / ${this.identifier}`);
            }
            return this.caseInstance;
        });
    }
    run() {
        return __awaiter(this, void 0, void 0, function* () {
            // console.log("Starting the run on " + this.identifier);
            yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.refreshCaseInstance();
                    if (!this.caseInstance) {
                        throw new Error(`Unexpectedly failing ${this.id} / ${this.identifier}`);
                    }
                    const caseInstance = this.caseInstance;
                    const totalNumAssertions = this.stateAssertions.length;
                    if (totalNumAssertions === 0) {
                        console.log(`\n============ Assertions have not been defined on case ${this.id} / ${this.identifier}\n`);
                        return;
                    }
                    console.log(`\n============ Running ${totalNumAssertions} assertions on case ${this.id} / ${this.identifier}:\n${caseInstance.printPlan()}\n`);
                    this.stateAssertions.forEach(assertion => {
                        const identifier = assertion.identifier;
                        const planItem = identifier.resolve(caseInstance);
                        if (!planItem) {
                            console.log(`- running assertion ${assertion} Failed, because the case has no plan item with identifier "${identifier}"`);
                            throw new Error(`Cannot find a plan item '${identifier}' in the case`);
                        }
                        try {
                            assertion.run(planItem);
                        }
                        catch (e) {
                            if (e instanceof Error) {
                                console.log(`- running assertion ${assertion} Failed: ${e.message}`);
                            }
                            else {
                                console.log(`- running assertion ${assertion} Failed: ${e}`);
                            }
                            throw e;
                        }
                        console.log(`- running assertion ${assertion} succeeded`);
                    });
                }
                catch (e) {
                    this.caseInstance = undefined; // Force another fetch attempt
                    console.log("Run on " + this.identifier + " gave an exception " + e.message);
                    throw e;
                }
            }));
        });
    }
}
exports.default = CaseAssertions;
