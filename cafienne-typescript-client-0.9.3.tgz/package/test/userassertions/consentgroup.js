"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = assertSameGroup;
exports.assertMemberRole = assertMemberRole;
exports.assertMemberHasNoRoles = assertMemberHasNoRoles;
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const consentgroupservice_1 = __importDefault(require("../../service/consentgroup/consentgroupservice"));
const comparison_1 = __importDefault(require("../comparison"));
function assertSameGroup(user_1, expectedGroup_1) {
    return __awaiter(this, arguments, void 0, function* (user, expectedGroup, trace = new trace_1.default()) {
        const actualGroup = yield consentgroupservice_1.default.getGroup(user, expectedGroup);
        if (!actualGroup) {
            throw new asyncerror_1.default(trace, `Cannot find a consent group ${expectedGroup}`);
        }
        sameProperty(expectedGroup, actualGroup, 'name', trace);
        sameProperty(expectedGroup, actualGroup, 'description', trace);
        const expectedUserIds = expectedGroup.members.map(m => m.userId);
        const actualUserIds = actualGroup.members.map(m => m.userId);
        const missingUserIds = expectedUserIds.filter(expectedUserId => !actualUserIds.find(id => id === expectedUserId));
        const tooManyUserIds = actualUserIds.filter(actualUserId => !expectedUserIds.find(id => id === actualUserId));
        if (missingUserIds.length > 0 || tooManyUserIds.length > 0) {
            const msg1 = missingUserIds.length > 0 ? 'Missing user ids: ' + missingUserIds.join(',') : '';
            const msg2 = missingUserIds.length > 0 ? 'Unexpected user ids: ' + tooManyUserIds.join(',') : '';
            throw new asyncerror_1.default(trace, `Consent group members mismatch:\n\t${msg1}\n\t${msg2}`);
        }
        expectedGroup.members.forEach(expectedMember => {
            const actualMember = actualGroup.members.find(member => member.userId === expectedMember.userId);
            if (!actualMember) {
                throw new asyncerror_1.default(trace, `Surprisingly we cannot find member ${expectedMember.userId} in the actual consent group`);
            }
            sameProperty(expectedMember, actualMember, 'isOwner', trace);
            if (!comparison_1.default.sameArray(expectedMember.roles, actualMember.roles)) {
                throw new asyncerror_1.default(trace, `Expected group member to have roles [${expectedMember.roles.join(', ')}] but found [${actualMember.roles.join(', ')}]`);
            }
            ;
        });
    });
}
function assertMemberRole(user_1, group_1, member_1, expectedRole_1) {
    return __awaiter(this, arguments, void 0, function* (user, group, member, expectedRole, trace = new trace_1.default()) {
        return consentgroupservice_1.default.getGroupMember(user, group, member, undefined, undefined, trace).then(actualMember => {
            if (!actualMember.roles.find(r => r === expectedRole)) {
                throw new asyncerror_1.default(trace, `Expected to find role '${expectedRole}' in member ${member}, but found roles [${actualMember.roles.join(',')}]`);
            }
        });
    });
}
function assertMemberHasNoRoles(user_1, group_1, member_1) {
    return __awaiter(this, arguments, void 0, function* (user, group, member, trace = new trace_1.default()) {
        return consentgroupservice_1.default.getGroupMember(user, group, member, undefined, undefined, trace).then(actualMember => {
            if (actualMember.roles.length > 0) {
                throw new asyncerror_1.default(trace, `Expected member ${member} in group ${group} to have no roles, but found roles [${actualMember.roles.join(',')}]`);
            }
        });
    });
}
function sameProperty(expected, actual, propertyName, trace) {
    if (expected[propertyName] !== actual[propertyName]) {
        throw new asyncerror_1.default(trace, `Expected ${expected.constructor.name} ${expected} to have ${propertyName} '${expected[propertyName]}' but found '${actual[propertyName]}'`);
    }
}
