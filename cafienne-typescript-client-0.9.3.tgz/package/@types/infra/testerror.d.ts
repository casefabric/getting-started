import StackTraceError from "./stacktraceerror";
export default class TestError extends StackTraceError {
    error: unknown;
    constructor(error: unknown, message: string);
}
//# sourceMappingURL=testerror.d.ts.map