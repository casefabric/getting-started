import TestRunner from "./testrunner";
export default class TestResults {
    list: Array<TestRunner>;
    constructor();
    addTest(result: TestRunner): void;
    toString(): string;
}
//# sourceMappingURL=testresults.d.ts.map