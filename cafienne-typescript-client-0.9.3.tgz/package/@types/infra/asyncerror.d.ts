import Trace from "./trace";
export default class AsyncError extends Error {
    constructor(trace: Trace, msg?: string);
}
//# sourceMappingURL=asyncerror.d.ts.map