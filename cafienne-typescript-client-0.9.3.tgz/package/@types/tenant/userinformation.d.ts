import CMMNBaseClass from "../cmmn/cmmnbaseclass";
import ConsentGroupMembership from "./consentgroupmembership";
import TenantUser from "./tenantuser";
export default class UserInformation extends CMMNBaseClass {
    userId: string;
    tenants: Array<TenantUser>;
    groups: Array<ConsentGroupMembership>;
    constructor(userId: string, tenants: Array<TenantUser>, groups: Array<ConsentGroupMembership>);
}
//# sourceMappingURL=userinformation.d.ts.map