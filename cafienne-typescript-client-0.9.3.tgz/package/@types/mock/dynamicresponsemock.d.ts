import MockServer from "./mockserver";
import PostMock from "./postmock";
export default class DynamicResponseMock extends MockServer {
    mock: PostMock;
    constructor(port: number);
}
//# sourceMappingURL=dynamicresponsemock.d.ts.map