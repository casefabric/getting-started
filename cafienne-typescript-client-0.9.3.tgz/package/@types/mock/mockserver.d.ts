import MockURL from './mockurl';
/**
 * Simple mock service, leveraging Express to handle POST and GET requests,
 * It has an in-memory "synchronization" mechanism through which it is possible to see if the mock is actually being invoked, including a timeout mechanism.
 * In order to use the mock service, for each end point you need to register a MockURL (e.g. a PostMock or a GetMock). This Mock must also be used for the synchronization.
 * Note that the same mock can be used for multiple calls to the end point, and it keeps track of the number of calls, including the number of waits for a call.
 * Also currently it allows to start/stop the Express service, but there is no state cleanup for it (and no testcase using it either).
 */
export default class MockServer {
    port: number;
    mocks: Array<MockURL>;
    private expressWrapper;
    constructor(port: number);
    /**
     * Returns express() on which URL listeners can be registered.
     */
    get express(): import("express-serve-static-core").Express;
    /**
     * Open the port (if not yet done), and register our mocks
     */
    start(): Promise<void>;
    /**
     * Stop the mock server
     */
    stop(): Promise<void>;
}
//# sourceMappingURL=mockserver.d.ts.map