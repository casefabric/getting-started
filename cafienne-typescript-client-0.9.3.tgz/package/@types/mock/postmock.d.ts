import MockURL from "./mockurl";
export default class PostMock extends MockURL {
    addRoute(): void;
}
//# sourceMappingURL=postmock.d.ts.map