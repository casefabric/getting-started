import Case from '../../cmmn/case';
import PlanItem from '../../cmmn/planitem';
import State from '../../cmmn/state';
import Trace from '../../infra/trace';
import User from '../../user';
/**
 * Retrieves the plan items of the case and asserts that the plan item has the expected state.
 * Optionally runs repeated loops to await the plan item to reach the expected state.
 * Handy to use for ProcessTask and CaseTasks and their potential follow-ups, as these tasks run asynchronously in the backend.
 * @param caseId
 * @param user
 * @param planItemIdentifier
 * @param planItemIndex
 * @param expectedState
 * @param maxAttempts
 * @param waitTimeBetweenAttempts
 * @returns {Promise<PlanItem>} the plan item if it is found
 * @throws {Error} if the plan item is not found after so many attempts
 */
export declare function assertPlanItem(user: User, caseId: Case | string, planItemIdentifier: string, planItemIndex?: number, expectedState?: State, trace?: Trace): Promise<PlanItem>;
/**
 * Asserts the state of the case plan
 * @param caseId
 * @param user
 * @param expectedState
 */
export declare function assertCasePlan(user: User, caseId: Case | string, expectedState?: State, trace?: Trace): Promise<Case>;
//# sourceMappingURL=plan.d.ts.map