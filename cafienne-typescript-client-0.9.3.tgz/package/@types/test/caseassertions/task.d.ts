import Task from '../../cmmn/task';
import TaskState from '../../cmmn/taskstate';
import Trace from '../../infra/trace';
import User from '../../user';
/**
 * Asserts that the task has expected state, assignee, and owner
 * @param task
 * @param user
 * @param action
 * @param expectedState
 * @param expectedAssignee
 * @param expectedOwner
 */
export declare function assertTask(user: User, task: Task | string, action: string, expectedState: TaskState, expectedAssignee?: User, expectedOwner?: User, expectedLastModifiedBy?: User, trace?: Trace): Promise<Task>;
/**
 * Verifies whether task's input is same as that of expected input
 * @param task
 * @param taskInput expected input
 */
export declare function verifyTaskInput(task: Task, taskInput: any): void;
/**
 * Finds and returns a particular task with in list of tasks
 * and throws an error if it does not exist
 * @param tasks
 * @param taskName
 */
export declare function findTask(tasks: Task[], taskName: string): Task;
/**
 * Asserts the number of tasks that have specified state with expected count
 * @param tasks
 * @param state
 * @param expectedCount
 */
export declare function assertTaskCount(tasks: Task[], state: string, expectedCount: Number): void;
//# sourceMappingURL=task.d.ts.map