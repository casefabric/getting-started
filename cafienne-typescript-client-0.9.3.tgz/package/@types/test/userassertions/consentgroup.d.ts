import Trace from "../../infra/trace";
import ConsentGroup from "../../service/consentgroup/consentgroup";
import User from "../../user";
export default function assertSameGroup(user: User, expectedGroup: ConsentGroup, trace?: Trace): Promise<void>;
export declare function assertMemberRole(user: User, group: ConsentGroup, member: User | string, expectedRole: string, trace?: Trace): Promise<void>;
export declare function assertMemberHasNoRoles(user: User, group: ConsentGroup, member: User | string, trace?: Trace): Promise<void>;
//# sourceMappingURL=consentgroup.d.ts.map