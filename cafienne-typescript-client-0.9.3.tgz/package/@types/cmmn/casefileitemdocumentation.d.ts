import CMMNBaseClass from "./cmmnbaseclass";
import CMMNDocumentation from "./cmmndocumentation";
/**
 * JSON Wrapper for case file item documentation in a case instance
 */
export default class CaseFileItemDocumentation extends CMMNBaseClass {
    path: string;
    documentation: CMMNDocumentation;
    /**
     *
     * @param path Plan item id
     * @param documentation Plan item name
     */
    constructor(path: string, documentation: CMMNDocumentation);
}
//# sourceMappingURL=casefileitemdocumentation.d.ts.map