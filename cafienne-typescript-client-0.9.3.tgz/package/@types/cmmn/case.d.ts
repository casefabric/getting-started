import PlanItem from './planitem';
import CaseTeam from './team/caseteam';
import CaseFile from './casefile';
import CMMNBaseClass from './cmmnbaseclass';
import Path from '../service/case/path';
/**
 * Wrapper for json response of Cafienne Service for a single case instance.
 */
export default class Case extends CMMNBaseClass {
    id: string;
    tenant: string;
    caseName: string;
    state: string;
    failures: number;
    parentCaseId: string;
    rootCaseId: string;
    createdOn: Date;
    createdBy: string;
    lastModified: string;
    modifiedBy: string;
    team: CaseTeam;
    planitems: Array<PlanItem>;
    file: CaseFile;
    /**
     *
     * @param id ID of the case
     * @param tenant Tenant in which the case resides
     * @param caseName Name of the case (taken from the definition)
     * @param state State of the case (taken from case plan)
     * @param failures Number of failures (plan items in state Failed) in this case
     * @param parentCaseId Id of parent case; is null or empty if there is no parent case
     * @param rootCaseId Id of the top most ancestor case. Is equal to the case id if there is no parent case
     * @param createdOn Timestamp of case creation
     * @param createdBy Id of user that created the case
     * @param lastModified Timestamp of last modification to the case
     * @param modifiedBy Id of user that last modified the case
     * @param team Array of members that form the case team
     * @param planitems List of all planitems created (or planned) inside the case
     * @param file JSON structor of the case file
     */
    constructor(id: string, tenant: string, caseName: string, state: string, failures: number, parentCaseId: string, rootCaseId: string, createdOn: Date, createdBy: string, lastModified: string, modifiedBy: string, team: CaseTeam, planitems: Array<PlanItem>, file: CaseFile);
    get plan(): PlanItem;
    toString(): string;
    /**
     * Returns the plan item matching the path, or throws an error
     * @param path - The path to resolve on the plan item structure of the case
     */
    findItem(path: Path | string): PlanItem;
    printPlan(): string;
}
//# sourceMappingURL=case.d.ts.map