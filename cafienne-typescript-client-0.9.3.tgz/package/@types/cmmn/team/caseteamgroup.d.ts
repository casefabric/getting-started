import ConsentGroup from "../../service/consentgroup/consentgroup";
import CMMNBaseClass from "../cmmnbaseclass";
export default class CaseTeamGroup extends CMMNBaseClass {
    mappings: Array<GroupRoleMapping>;
    groupId: string;
    /**
     * Base case team member, supporting all types (tenant-user vs. tenant-role and whether case owner or not)
     * @param user Either a String or a User, holding the user id of the case team member
     * @param roles Set of roles that the user has within this case team; if not given, then the roles of the user are used (if any)
     * @param memberType The type of member (either a 'user' or a 'role')
     * @param isOwner Whether or not the new member is also a Case Owner
     */
    constructor(group: ConsentGroup | string, mappings?: Array<GroupRoleMapping>);
    toString(): string;
}
export declare class GroupRoleMapping {
    groupRole: string;
    isOwner: boolean;
    caseRoles: Array<string>;
    constructor(groupRole: string, caseRoleList: string | Array<string>);
}
export declare class GroupRoleMappingWithCaseOwnership extends GroupRoleMapping {
    groupRole: string;
    isOwner: boolean;
    constructor(groupRole: string, caseRoleList: string | Array<string>);
}
//# sourceMappingURL=caseteamgroup.d.ts.map