import User from '../user';
import QueryFilter from './queryfilter';
import CafienneResponse from './response';
import { Document } from '@xmldom/xmldom';
export default class CafienneService {
    static calls: number;
    /**
     * Returns base headers (copying case-last-modified and tenant-last-modified) and
     * sets a new bearer token based on the user's token
     * Optionally copies the additional headers from the "from" object
     * @param user
     * @param from
     */
    static getHeaders(user: User, from?: any): any;
    static get baseURL(): string;
    static updateCaseLastModified(response: CafienneResponse): Promise<CafienneResponse>;
    static post(url: string, user: User, request?: object, method?: string): Promise<CafienneResponse>;
    static postXML(url: string, user: User, request: Document, method?: string): Promise<CafienneResponse>;
    static put(url: string, user: User, request?: object): Promise<CafienneResponse>;
    static delete(url: string, user: User): Promise<CafienneResponse>;
    static patch(user: User, url: string): Promise<CafienneResponse>;
    static get(url: string, user: User | undefined, filter?: QueryFilter, headers?: any): Promise<CafienneResponse>;
    static getXml(url: string, user: User): Promise<Document>;
    static fetch(user: User | undefined, url: string, method: string, headers?: any, body?: string): Promise<CafienneResponse>;
}
export declare function printHeaders(msg: string, headers: {}): void;
//# sourceMappingURL=cafienneservice.d.ts.map