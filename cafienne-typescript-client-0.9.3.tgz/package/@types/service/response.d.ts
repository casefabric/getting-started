import Trace from '../infra/trace';
export default class CafienneResponse {
    response: Response;
    private json_prop?;
    private text_prop;
    private hasText;
    /**
     * Simple wrapper around isomorphic-fetch response.
     * But this one you can invoke .text() and .json() multiple times and also both can be invoked on same response (unlike in node-fetch)
     * @param response
     */
    constructor(response: Response);
    /**
     * Creates a json object structure with response status code, status text and response message
     */
    asJSON(): Promise<{
        statusCode: number;
        statusMessage: string;
        body: any;
    }>;
    get ok(): boolean;
    get redirected(): boolean;
    get status(): number;
    get statusText(): string;
    get type(): ResponseType;
    get url(): string;
    get headers(): Headers;
    xml(): Promise<import("@xmldom/xmldom").Document>;
    text(): Promise<string>;
    json(): Promise<any>;
}
/**
 * Validates the HTTP Response object.
 * If it succeeded, but failures where expected, it will throw an error with the given error message.
 * If it fails, but it was expected to succeed, an error with the response text will be thrown.
 * In all other cases the response itself will be returned.
 *
 * @param response
 * @param errorMsg
 * @param expectedStatusCode
 */
export declare function checkResponse(response: CafienneResponse, errorMsg: string, expectedStatusCode: number, trace?: Trace): Promise<CafienneResponse>;
/**
 * Validates the response for failure by invoking checkResponse function internally.
 * If that validation succeeds, the json of the response is returned.
 * @param response
 * @param errorMsg
 * @param expectedStatusCode
 */
export declare function checkJSONResponse(response: CafienneResponse, errorMsg: string | undefined, expectedStatusCode: number, returnType?: Function | Array<Function>, trace?: Trace): Promise<any>;
//# sourceMappingURL=response.d.ts.map