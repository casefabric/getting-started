import ActorEvents from "./actorevents";
export default class TenantEvents extends ActorEvents {
}
//# sourceMappingURL=tenantevents.d.ts.map