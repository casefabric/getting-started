import Case from "../../cmmn/case";
import PlanItem from "../../cmmn/planitem";
import Trace from '../../infra/trace';
import User from "../../user";
import ActorEvents from "./actorevents";
import PlanItemEvents from "./planitemevents";
import ProcessEvents from "./processevents";
/**
 * CaseEvents enables building a hierarchy of a case events with those from it's CaseTasks and ProcessTasks.
 */
export default class CaseEvents extends PlanItemEvents {
    user: User;
    parentCase?: CaseEvents | undefined;
    static from(user: User, caseInstance: Case): CaseEvents;
    cases: Array<CaseEvents>;
    processes: Array<ProcessEvents>;
    private constructor();
    load(trace?: Trace): Promise<void>;
    addCase(subCase: PlanItem): CaseEvents;
    findItem(name: string, type?: string): ActorEvents | undefined;
    findProcessTask(name: string): ProcessEvents | undefined;
    private collect;
    print(indent?: string): string;
    printEvents(indent?: string): string;
    loadEventHierarchy(user?: User, trace?: Trace): Promise<void>;
    get totalEventCount(): number;
    hasArchivedHierarchy(): boolean;
    isArchived(): boolean;
    assertArchivedHierarchy(user?: User, trace?: Trace): Promise<any>;
    assertRestored(user?: User, trace?: Trace): Promise<any>;
    assertDeleted(user?: User, trace?: Trace): Promise<any>;
    toString(): string;
}
//# sourceMappingURL=caseevents.d.ts.map