import Trace from "../../infra/trace";
import User from "../../user";
/**
 * Base class to retrieve the events of the actor from the event journal
 */
export default class ActorEvents {
    user: User;
    id: string;
    name: string;
    events: Array<any>;
    type: string;
    constructor(user: User, id: string, name?: string);
    toString(): string;
    mustBeArchived(user?: User, trace?: Trace): Promise<void>;
    assertArchived(user?: User, trace?: Trace): Promise<any>;
    assertDeleted(user?: User, trace?: Trace, loader?: Function): Promise<any>;
    protected hasArchiveEvent(archiveEventName: string): boolean;
    isArchived(): boolean;
    loadEvents(user?: User, trace?: Trace): Promise<void>;
    print(indent: string): string;
    description(indent: string): string;
    printEvents(indent?: string): string;
    get totalEventCount(): number;
}
//# sourceMappingURL=actorevents.d.ts.map