import PlanItem from "../../cmmn/planitem";
import State from "../../cmmn/state";
import Trace from "../../infra/trace";
import CaseEvents from "./caseevents";
import PlanItemEvents from "./planitemevents";
export default class ProcessEvents extends PlanItemEvents {
    parentCase: CaseEvents;
    constructor(item: PlanItem, parentCase: CaseEvents);
    isArchived(): boolean;
    assertState(state: State, trace?: Trace): Promise<PlanItem>;
}
//# sourceMappingURL=processevents.d.ts.map