import Case from '../../cmmn/case';
import Trace from '../../infra/trace';
export default class RequestService {
    static requestCase(casePath: string | undefined, inputs: any, caseInstanceId?: string, debug?: boolean, expectedStatusCode?: number, trace?: Trace): Promise<Case>;
}
//# sourceMappingURL=requestservice.d.ts.map