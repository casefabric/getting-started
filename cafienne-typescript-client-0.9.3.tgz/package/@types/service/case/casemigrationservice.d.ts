import User from "../../user";
import Case from "../../cmmn/case";
import Definitions from "../../cmmn/definitions/definitions";
import CaseTeam from "../../cmmn/team/caseteam";
import Trace from "../../infra/trace";
export default class CaseMigrationService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static migrateDefinition(user: User, Case: Case, migration: DefinitionMigration, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<any>;
}
export declare class DefinitionMigration {
    newDefinition: string | Definitions;
    newTeam?: CaseTeam | undefined;
    constructor(newDefinition: string | Definitions, newTeam?: CaseTeam | undefined);
}
//# sourceMappingURL=casemigrationservice.d.ts.map