import Case from "../../cmmn/case";
import PlanItem from "../../cmmn/planitem";
export default class Path {
    private raw;
    static from(path: Path | string): Path;
    child: Path | undefined;
    name: string;
    index: number;
    part: string;
    constructor(raw: string, slashedParts?: string[]);
    resolve(caseInstance: Case | undefined): PlanItem | undefined;
    private walkPath;
    is(path: Path): boolean;
    get formatted(): string;
    toString(): string;
}
export declare class Identifier extends Path {
    constructor(identifier: string);
    resolve(caseInstance: Case): PlanItem | undefined;
}
//# sourceMappingURL=path.d.ts.map