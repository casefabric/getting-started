import { Document } from '@xmldom/xmldom';
import DeployCase from './command/repository/deploycase';
import User from '../../user';
import Tenant from '../../tenant/tenant';
import Definitions from '../../cmmn/definitions/definitions';
import Trace from '../../infra/trace';
export default class RepositoryService {
    /**
     * Deploy a case model
     * @param command
     * @param user
     */
    static deployCase(user: User, command: DeployCase, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Loads a case definition from the server
     * @param fileName
     * @param user
     * @param tenant
     */
    static loadCaseDefinition(user: User, fileName: string, tenant: string | Tenant, expectedStatusCode?: number): Promise<Document>;
    /**
     * Fetch cases for the user
     * @param tenant
     * @param user
     */
    static listCaseDefinitions(user: User, tenant?: string | Tenant, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Invokes the validation API
     * @param source
     */
    static validateCaseDefinition(user: User, source: Document | string | Definitions, expectedStatusCode?: number, trace?: Trace): Promise<string[] | import("../response").default>;
    /**
     * Combines validation and deployment call in one shot, based on the name of a locally available file
     * @param fileName File containing the case definitions.
     * @param user User that deploys the case definition.
     * @param tenant Tenant in which the definition is deployed.
     */
    static validateAndDeploy(user: User, fileName: string, tenant: string | Tenant, trace?: Trace): Promise<void>;
}
/**
 * Parses a file name into an XML document.
 * Reads the file from the configured location on the local system (where this testcase runs)
 * @param fileName
 */
export declare function readLocalXMLDocument(content: any): Document;
/**
 * Parses a file name into an XML document.
 * Reads the file from the configured location on the local system (where this testcase runs)
 * @param content If it is an XML Document, then nothing. If it is a file or Definitions, then it will be added as string to compose filename
 */
export declare function readLocalFile(content: any): string;
//# sourceMappingURL=repositoryservice.d.ts.map