import Case from '../../cmmn/case';
import CafienneEvent from '../../cmmn/event/cafienneevent';
import Trace from '../../infra/trace';
import Tenant from '../../tenant/tenant';
import User from '../../user';
export default class DebugService {
    /**
     * Retrieve model events from the backend for a specific ModelActor
     * @param model Id of the model to retrieve events from
     * @param user
     */
    static getEvents(model: string | Case | Tenant, user?: User): Promise<import("../response").default>;
    static getParsedEvents(model: string | Case | Tenant, user?: User, trace?: Trace): Promise<Array<CafienneEvent>>;
    static forceRecovery(user: User, model: string | Case | Tenant): Promise<import("../response").default>;
}
//# sourceMappingURL=debugservice.d.ts.map