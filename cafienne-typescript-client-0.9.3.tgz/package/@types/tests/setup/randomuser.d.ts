import TenantUser from "../../tenant/tenantuser";
import User from "../../user";
export default class RandomUser extends TenantUser {
    constructor(id?: string | User, roles?: Array<string>);
}
//# sourceMappingURL=randomuser.d.ts.map