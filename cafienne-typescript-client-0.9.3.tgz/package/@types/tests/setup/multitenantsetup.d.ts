import User from "../../user";
import TenantUser, { TenantOwner } from "../../tenant/tenantuser";
import Tenant from "../../tenant/tenant";
import ConsentGroup from "../../service/consentgroup/consentgroup";
/**
 * Somewhat complexer tenant setup, along with consent groups
 */
export default class MultiTenantSetup {
    platformAdmin: User;
    girl: TenantOwner;
    boy: TenantOwner;
    dad: TenantUser;
    mom: TenantUser;
    neil: TenantUser;
    buzz: TenantUser;
    irwin: TenantUser;
    elon: TenantUser;
    jeff: TenantUser;
    alien: TenantUser;
    martian: TenantUser;
    people: TenantUser[];
    moonmen: TenantUser[];
    martians: TenantUser[];
    world: Tenant;
    moon: Tenant;
    mars: Tenant;
    futureWorld: Tenant;
    groupRoleUser: string;
    groupRoleTester: string;
    moonGroup: ConsentGroup;
    marsGroup: ConsentGroup;
    marsGroup2: ConsentGroup;
    constructor(platformAdmin?: User);
    /**
     * Creates the tenant, and logs in for sender user and receiver user.
     */
    create(): Promise<void>;
}
//# sourceMappingURL=multitenantsetup.d.ts.map