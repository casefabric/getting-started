"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("../../config"));
const trace_1 = __importDefault(require("../../infra/trace"));
const logger_1 = __importDefault(require("../../logger"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const consentgroup_1 = __importDefault(require("./consentgroup"));
const consentgroupmember_1 = __importDefault(require("./consentgroupmember"));
/**
 * Connection to the /consent-group APIs of Cafienne
 */
class ConsentGroupService {
    /**
     * Creates the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static createGroup(user_1, tenant_1, group_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, group, expectedStatusCode = 200, msg = `CreateConsentGroup is not expected to succeed for user ${user.id} in ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/tenant/${tenant}/consent-groups`, user, group.toJson());
            if (response.status === 400 && expectedStatusCode === 200) {
                const responseText = yield response.text();
                if (responseText === 'Consent group already exists' || responseText.indexOf('Failure while handling message CreateConsentGroup') >= 0) {
                    // Tenant already exists is ok.
                    if (config_1.default.PlatformService.log)
                        logger_1.default.debug(`Consent group ${group} already exists.'`);
                    return response;
                }
            }
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, undefined, trace).then(json => {
                // After getting a succesful response we silently set the group id if not available
                //  (typical use case: the server generated it instead the client passing it)
                if (!group.id && json.groupId) {
                    group.id = json.groupId;
                }
            });
        });
    }
    /**
     * Retrieve a consent group with it's members
     * @param user Must be a valid user in the group
     * @param groupId
     * @param expectedStatusCode
     */
    static getGroup(user_1, groupId_1) {
        return __awaiter(this, arguments, void 0, function* (user, groupId, expectedStatusCode = 200, msg = `GetGroup is not expected to succeed for user ${user.id} in group ${groupId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/consent-group/${groupId}`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, consentgroup_1.default, trace);
        });
    }
    /**
     * Replaces the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static replaceGroup(user_1, group_1) {
        return __awaiter(this, arguments, void 0, function* (user, group, expectedStatusCode = 202, msg = `ReplaceConsentGroup is not expected to succeed for user ${user.id} in ${group}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/consent-group/${group}`, user, group.toJson());
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Retrieve information about a specific user in the group
     * @param user Must be a group user
     * @param groupId
     * @param userId User or Id of the user to retrieve the information for
     * @param expectedStatusCode
     */
    static getGroupMember(user_1, groupId_1, userId_1) {
        return __awaiter(this, arguments, void 0, function* (user, groupId, userId, expectedStatusCode = 200, msg = `GetGroupMember(${userId}) is not expected to succeed for user ${user.id} in group ${groupId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/consent-group/${groupId}/members/${userId}`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, consentgroupmember_1.default, trace);
        });
    }
    /**
     * Add or replace a user in the group
     * @param user Must be a group owner
     * @param groupId Group in which to add/replace the member.
     * @param newUser The new user information that will be updated
     * @param expectedStatusCode
     */
    static setGroupMember(user_1, groupId_1, newUser_1) {
        return __awaiter(this, arguments, void 0, function* (user, groupId, newUser, expectedStatusCode = 202, msg = `SetGroupMember is not expected to succeed for user ${user.id} in consent group ${groupId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/consent-group/${groupId}/members`, user, newUser.toJson());
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     *
     * @param user Must be a group owner
     * @param groupId Group to remove the member from
     * @param userId User or id of user to be removed from the group.
     * @param expectedStatusCode
     * @returns
     */
    static removeGroupMember(user_1, groupId_1, userId_1) {
        return __awaiter(this, arguments, void 0, function* (user, groupId, userId, expectedStatusCode = 202, msg = `RemoveGroupMember ${userId} from group ${groupId} is not expected to succeed for user ${user.id}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/consent-group/${groupId}/members/${userId}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
}
exports.default = ConsentGroupService;
