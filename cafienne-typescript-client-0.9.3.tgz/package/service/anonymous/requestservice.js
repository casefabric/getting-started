"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const case_1 = __importDefault(require("../../cmmn/case"));
const trace_1 = __importDefault(require("../../infra/trace"));
const user_1 = __importDefault(require("../../user"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
class RequestService {
    static requestCase() {
        return __awaiter(this, arguments, void 0, function* (casePath = '', inputs, caseInstanceId, debug, expectedStatusCode = 200, trace = new trace_1.default()) {
            console.log("Anonymously requesting Case[" + casePath + "]");
            const url = `/request/case/${casePath}`;
            const response = yield cafienneservice_1.default.post(url, user_1.default.NONE, { inputs, caseInstanceId, debug });
            const msg = `Anonymously requesting Case is not expected to succeed`;
            const json = yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, case_1.default, trace);
            // Hack: copy "StartCaseResponse.caseInstanceId" to "Case.id" in the json prior to instantiating Case.
            // TODO: consider whether it is better to work with a "StartCaseResponse" object instead
            if (response.ok) {
                json.id = json.caseInstanceId;
                console.log(`Created case instance with id: \t${json.id}`);
            }
            return json;
        });
    }
}
exports.default = RequestService;
