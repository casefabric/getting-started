"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const time_1 = require("../../test/time");
const debugservice_1 = __importDefault(require("../case/debugservice"));
/**
 * Base class to retrieve the events of the actor from the event journal
 */
class ActorEvents {
    constructor(user, id, name = id) {
        this.user = user;
        this.id = id;
        this.name = name;
        this.events = [];
        this.type = this.constructor.name.split('Events')[0];
    }
    toString() {
        return `${this.type} ${this.id}`;
    }
    mustBeArchived() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            yield this.loadEvents(user, trace);
            if (!this.isArchived()) {
                console.log("Found unexpected events: " + JSON.stringify(this.events, undefined, 2));
                throw new asyncerror_1.default(trace, `${this} is not found in archived state`);
            }
        });
    }
    assertArchived() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            return yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                console.log(`Checking that ${this} is archived ...`);
                yield this.mustBeArchived(user, trace);
            }));
        });
    }
    assertDeleted() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default(), loader = () => __awaiter(this, void 0, void 0, function* () { return yield this.loadEvents(user, trace); })) {
            return yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                console.log(`Checking that ${this} is deleted ...`);
                yield loader();
                if (this.totalEventCount > 0) {
                    throw new asyncerror_1.default(trace, `Did not expect to find any events in ${this}, but found ${this.totalEventCount}:\n${this.printEvents()}`);
                }
            }));
        });
    }
    hasArchiveEvent(archiveEventName) {
        // Note: a sub case or sub process is archived when it is active.
        //  If it was in Available state, then there was no need to archive it, 
        //  and then there will not be any events (i.e. events.length === 0)
        if (this.events.length === 0) {
            return true;
        }
        else if (this.events.length === 1 && this.events[0].type === archiveEventName) {
            //  If archived, then there must be exactly one event, with the given event name.
            return true;
        }
        else {
            // So, it is not (yet?) archived ...
            return false;
        }
    }
    isArchived() {
        throw new Error(`This method must be implemented in ${this.constructor.name}`);
    }
    loadEvents() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            const response = yield debugservice_1.default.getEvents(this.id, user).then(data => data.asJSON());
            if (!response.body) {
                console.log('Expected a response with a body, but received something else', response);
                throw new asyncerror_1.default(trace, 'Expected a response with a body, but received something else');
            }
            this.events = [];
            this.events.push(...response.body);
        });
    }
    print(indent) {
        return this.description(indent);
    }
    description(indent) {
        if (this.name === this.id) {
            return `${this.type}[${this.id}]`;
        }
        else {
            return `${this.type}['${this.name}' - ${this.id}]`;
        }
    }
    printEvents(indent = '') {
        const eventDescriber = (event) => `${event.type}`;
        const list = () => {
            if (this.events.length === 1) {
                return eventDescriber(this.events[0]);
            }
            else if (this.events.length) {
                return this.events.map(eventDescriber).join(', ');
            }
            else {
                return '';
            }
        };
        return `${this.description(indent)}\n${indent}   events: [${list()}]`;
    }
    get totalEventCount() {
        return this.events.length;
    }
}
exports.default = ActorEvents;
