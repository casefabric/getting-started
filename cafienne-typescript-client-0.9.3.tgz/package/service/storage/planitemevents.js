"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const state_1 = __importDefault(require("../../cmmn/state"));
const trace_1 = __importDefault(require("../../infra/trace"));
const time_1 = require("../../test/time");
const actorevents_1 = __importDefault(require("./actorevents"));
class PlanItemEvents extends actorevents_1.default {
    constructor(user, item, parentCase) {
        super(user, item.id, item.name);
        this.user = user;
        this.parentCase = parentCase;
        this.state = state_1.default.of(item.currentState);
    }
    assertArchived() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            return yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                console.log("Checking that we're archived ...");
                yield this.mustBeArchived(user, trace);
            }));
        });
    }
    hasArchiveEvent(archiveEventName) {
        // Note: a sub case or sub process is archived when it is active.
        //  If it was in Available state, then there was no need to archive it, 
        //  and then there will not be any events (i.e. events.length === 0)
        if (this.events.length === 0) {
            return true;
        }
        else if (this.events.length === 1 && this.events[0].type === archiveEventName) {
            //  If archived, then there must be exactly one event, with the given event name.
            return true;
        }
        else {
            // So, it is not (yet?) archived ...
            return false;
        }
    }
    isArchived() {
        throw new Error(`This method must be implemented in ${this.constructor.name}`);
    }
}
exports.default = PlanItemEvents;
