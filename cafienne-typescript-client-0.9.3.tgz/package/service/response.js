"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkResponse = checkResponse;
exports.checkJSONResponse = checkJSONResponse;
const xmldom_1 = require("@xmldom/xmldom");
const asyncerror_1 = __importDefault(require("../infra/asyncerror"));
const trace_1 = __importDefault(require("../infra/trace"));
class CafienneResponse {
    /**
     * Simple wrapper around isomorphic-fetch response.
     * But this one you can invoke .text() and .json() multiple times and also both can be invoked on same response (unlike in node-fetch)
     * @param response
     */
    constructor(response) {
        this.response = response;
        this.text_prop = '';
        this.hasText = false;
    }
    /**
     * Creates a json object structure with response status code, status text and response message
     */
    asJSON() {
        return __awaiter(this, void 0, void 0, function* () {
            const tryParseJSON = (text) => __awaiter(this, void 0, void 0, function* () {
                try {
                    return JSON.parse(text || '');
                }
                catch (e) {
                    console.log("Could not parse json: ", e);
                    return text;
                }
            });
            const body = yield this.text().then(tryParseJSON);
            return {
                statusCode: this.status,
                statusMessage: this.statusText,
                body
            };
        });
    }
    get ok() {
        return this.response.ok;
    }
    get redirected() {
        return this.response.redirected;
    }
    get status() {
        return this.response.status;
    }
    get statusText() {
        return this.response.statusText;
    }
    get type() {
        return this.response.type;
    }
    get url() {
        return this.response.url;
    }
    get headers() {
        return this.response.headers;
    }
    xml() {
        return __awaiter(this, void 0, void 0, function* () {
            const xml = yield this.text();
            const parser = new xmldom_1.DOMParser();
            const document = parser.parseFromString(xml, 'application/xml');
            return document;
        });
    }
    text() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.hasText) {
                return this.text_prop;
            }
            return this.response.text().then(text => {
                this.text_prop = text;
                this.hasText = true;
                return text;
            });
        });
    }
    json() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.json_prop) {
                return this.json_prop;
            }
            const text = yield this.text();
            this.json_prop = JSON.parse(text || '');
            return this.json_prop;
        });
    }
}
exports.default = CafienneResponse;
/**
 * Validates the HTTP Response object.
 * If it succeeded, but failures where expected, it will throw an error with the given error message.
 * If it fails, but it was expected to succeed, an error with the response text will be thrown.
 * In all other cases the response itself will be returned.
 *
 * @param response
 * @param errorMsg
 * @param expectedStatusCode
 */
function checkResponse(response_1, errorMsg_1, expectedStatusCode_1) {
    return __awaiter(this, arguments, void 0, function* (response, errorMsg, expectedStatusCode, trace = new trace_1.default()) {
        if (response.status !== expectedStatusCode) {
            const responseText = yield response.text();
            if (expectedStatusCode >= 200 && expectedStatusCode < 300) {
                // Change error messages, by default 
                // Is not expected to succeed ===> Is expected to succeed
                errorMsg = errorMsg.replace('is not expected to succeed for user', 'is expected to succeed for user');
            }
            if (!errorMsg) {
                errorMsg = `Expected status ${expectedStatusCode} instead of ${response.status} ${response.statusText}: ${responseText}`;
            }
            throw new asyncerror_1.default(trace, errorMsg);
        }
        return response;
    });
}
/**
 * Validates the response for failure by invoking checkResponse function internally.
 * If that validation succeeds, the json of the response is returned.
 * @param response
 * @param errorMsg
 * @param expectedStatusCode
 */
function checkJSONResponse(response_1) {
    return __awaiter(this, arguments, void 0, function* (response, errorMsg = '', expectedStatusCode, returnType, trace = new trace_1.default()) {
        yield checkResponse(response, errorMsg, expectedStatusCode, trace);
        if (response.ok) {
            const json = yield response.json();
            if (returnType) {
                // console.log("Response is " + JSON.stringify(json, undefined, 2))
                // console.log("\n\n Return type is " , returnType)
                if (returnType instanceof Array) {
                    if (returnType.length == 0) {
                        if (!errorMsg) {
                            errorMsg = 'Return type must have at least 1 element';
                        }
                        throw new asyncerror_1.default(trace, errorMsg);
                    }
                    const constructorCall = returnType[0];
                    if (json instanceof Array) {
                        const array = json;
                        return array.map(tenantUser => Object.assign(new constructorCall, tenantUser));
                    }
                    else {
                        if (!errorMsg) {
                            errorMsg = `Expected a json array with objects of type ${constructorCall.name}, but the response was not an array: ${JSON.stringify(json, undefined, 2)}`;
                        }
                        throw new asyncerror_1.default(trace, errorMsg);
                    }
                }
                else if (returnType !== undefined) {
                    const constructorCall = returnType;
                    return Object.assign(new constructorCall(), json);
                }
            }
            return json;
        }
        else {
            return response;
        }
    });
}
