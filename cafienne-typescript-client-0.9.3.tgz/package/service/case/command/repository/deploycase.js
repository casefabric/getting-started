"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Interface with fields required to deploy a CMMN case into the Cafienne Engine
 */
class DeployCase {
    /**
     *
     * @param definition XML File with the <definitions> in it
     * @param modelName Filename under which the case will be identified ('.xml' extension is added by the server)
     * @param tenant Tenant in which the case must be deployed. If not given, the defaut tenant of the case system is used.
     */
    constructor(definition, modelName, tenant) {
        this.definition = definition;
        this.modelName = modelName;
        this.tenant = tenant;
    }
}
exports.default = DeployCase;
