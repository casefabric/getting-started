"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const planitem_1 = __importDefault(require("../../cmmn/planitem"));
const cmmndocumentation_1 = __importDefault(require("../../cmmn/cmmndocumentation"));
const trace_1 = __importDefault(require("../../infra/trace"));
class CasePlanService {
    /**
     * Get the list of plan items of the case instance
     * @param Case
     * @param user
     */
    static getPlanItems(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `GetPlanItems is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/planitems`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [planitem_1.default], trace);
        });
    }
    /**
     * Get the plan item
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItem(user_1, caseId_1, planItemId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, planItemId, expectedStatusCode = 200, msg = `GetPlanItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/planitems/${planItemId}`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, planitem_1.default, trace);
        });
    }
    /**
     * Get the plan item's documentation
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItemDocumentation(user_1, caseId_1, planItemId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, planItemId, expectedStatusCode = 200, msg = `GetPlanItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/documentation/planitems/${planItemId}`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, cmmndocumentation_1.default, trace);
        });
    }
    /**
     * Tell the plan item to make the specified transition
     * @param Case
     * @param user
     * @param planItemId
     */
    static makePlanItemTransition(user_1, caseId_1, planItemId_1, transition_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, planItemId, transition, expectedStatusCode = 200, msg = `MakePlanItemTransition is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/planitems/${planItemId}/${transition}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Tell the event to occur
     * @param Case
     * @param user
     * @param eventName
     */
    static raiseEvent(user_1, caseId_1, eventName_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, eventName, expectedStatusCode = 200, msg = `RaiseEvent is not expected to succeed for user ${user} in case ${caseId} on event ${eventName}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/planitems/${eventName}/Occur`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
}
exports.default = CasePlanService;
