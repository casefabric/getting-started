"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.readLocalXMLDocument = readLocalXMLDocument;
exports.readLocalFile = readLocalFile;
const fs_1 = __importDefault(require("fs"));
const xmldom_1 = require("@xmldom/xmldom");
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const config_1 = __importDefault(require("../../config"));
const response_1 = require("../response");
const comparison_1 = __importDefault(require("../../test/comparison"));
const logger_1 = __importDefault(require("../../logger"));
const tenant_1 = __importDefault(require("../../tenant/tenant"));
const trace_1 = __importDefault(require("../../infra/trace"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const FileSystem = fs_1.default;
class RepositoryService {
    /**
     * Deploy a case model
     * @param command
     * @param user
     */
    static deployCase(user_1, command_1) {
        return __awaiter(this, arguments, void 0, function* (user, command, expectedStatusCode = 204, msg = `Deployment of case ${command.modelName} failed`, trace = new trace_1.default()) {
            if (!user) {
                throw new Error('User must be specified');
            }
            const tenantQueryParameter = command.tenant ? 'tenant=' + command.tenant : '';
            // Hmmm... Duplicate '/repository/repository/' is needed currently...
            const url = `/repository/deploy/${command.modelName}?${tenantQueryParameter}`;
            const response = yield cafienneservice_1.default.postXML(url, user, command.definition);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Loads a case definition from the server
     * @param fileName
     * @param user
     * @param tenant
     */
    static loadCaseDefinition(user_1, fileName_1, tenant_2) {
        return __awaiter(this, arguments, void 0, function* (user, fileName, tenant, expectedStatusCode = 200) {
            const modelName = fileName.endsWith('.xml') ? fileName.substring(0, fileName.length - 4) : fileName;
            const xml = yield cafienneservice_1.default.getXml(`/repository/load/${modelName}?tenant=${getTenantName(tenant)}`, user);
            return xml;
        });
    }
    /**
     * Fetch cases for the user
     * @param tenant
     * @param user
     */
    static listCaseDefinitions(user_1, tenant_2) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 200, msg = `ListCaseDefinitions is not expected to succeed for member ${user}`, trace = new trace_1.default()) {
            const tenantQueryParameter = tenant ? '?tenant=' + getTenantName(tenant) : '';
            const response = yield cafienneservice_1.default.get(`/repository/list${tenantQueryParameter}`, user);
            const json = (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
            if (config_1.default.RepositoryService.log) {
                logger_1.default.debug('Cases deployed in the server: ' + JSON.stringify(json, undefined, 2));
            }
            return json;
        });
    }
    /**
     * Invokes the validation API
     * @param source
     */
    static validateCaseDefinition(user_1, source_1) {
        return __awaiter(this, arguments, void 0, function* (user, source, expectedStatusCode = 200, trace = new trace_1.default()) {
            const url = `/repository/validate`;
            const xml = readLocalXMLDocument(source);
            const response = yield cafienneservice_1.default.postXML(url, user, xml);
            const status = response.status;
            if (status !== expectedStatusCode) {
                if (response.ok) {
                    const responseText = yield response.text();
                    throw new asyncerror_1.default(trace, `Expected status ${expectedStatusCode} instead of ${status} ${response.statusText}: ${responseText}`);
                }
                else {
                    const messages = yield response.json();
                    throw new asyncerror_1.default(trace, `Validation failed: ${response.statusText}\n${messages.join('\n')}`);
                }
            }
            else {
                if (response.ok) {
                    return response;
                }
                else {
                    const messages = yield response.json();
                    return messages;
                }
            }
        });
    }
    /**
     * Combines validation and deployment call in one shot, based on the name of a locally available file
     * @param fileName File containing the case definitions.
     * @param user User that deploys the case definition.
     * @param tenant Tenant in which the definition is deployed.
     */
    static validateAndDeploy(user_1, fileName_1, tenant_2) {
        return __awaiter(this, arguments, void 0, function* (user, fileName, tenant, trace = new trace_1.default()) {
            const tenantName = tenant instanceof tenant_1.default ? tenant.name : tenant;
            const definition = readLocalXMLDocument(fileName);
            const modelName = fileName;
            const serverVersion = yield this.loadCaseDefinition(user, modelName, tenantName);
            if (comparison_1.default.sameXML(definition, serverVersion)) {
                if (config_1.default.RepositoryService.log) {
                    logger_1.default.debug(`Skipping deployment of ${fileName}, as server already has it`);
                }
                return;
            }
            yield this.validateCaseDefinition(user, definition, undefined, trace);
            yield this.deployCase(user, { definition, modelName, tenant: tenantName }, undefined, undefined, trace);
        });
    }
}
exports.default = RepositoryService;
/**
 * Parses a file name into an XML document.
 * Reads the file from the configured location on the local system (where this testcase runs)
 * @param fileName
 */
function readLocalXMLDocument(content) {
    if (content.constructor.name == 'Document') {
        return content;
    }
    const parser = new xmldom_1.DOMParser();
    return parser.parseFromString(readLocalFile(content), 'application/xml');
}
/**
 * Parses a file name into an XML document.
 * Reads the file from the configured location on the local system (where this testcase runs)
 * @param content If it is an XML Document, then nothing. If it is a file or Definitions, then it will be added as string to compose filename
 */
function readLocalFile(content) {
    if (content.constructor.name == 'Document') {
        return content;
    }
    if (!FileSystem.existsSync(config_1.default.RepositoryService.repository_folder)) {
        throw new Error(`The configured repository folder '${config_1.default.RepositoryService.repository_folder}' cannot be found`);
    }
    const fileName = config_1.default.RepositoryService.repository_folder + '/' + content;
    if (!FileSystem.existsSync(fileName)) {
        throw new Error(`File ${fileName} cannot be found on the local file system`);
    }
    return FileSystem.readFileSync(fileName, 'utf8');
}
function getTenantName(tenant) {
    return tenant instanceof tenant_1.default ? tenant.name : tenant;
}
