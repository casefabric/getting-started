"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const caseteam_1 = __importDefault(require("../../cmmn/team/caseteam"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const trace_1 = __importDefault(require("../../infra/trace"));
class CaseTeamService {
    /**
     * Get the CaseTeam of the specified case instance
     * @param caseInstance
     * @param user
     * @returns CaseTeam
     */
    static getCaseTeam(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `GetCaseTeam is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/caseteam`, user);
            const caseTeam = yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, caseteam_1.default, trace);
            return caseTeam;
        });
    }
    /**
     * Assign the specified team to the case
     * @param Case
     * @param user
     * @param team
     */
    static setCaseTeam(user_1, caseId_1, team_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, team, expectedStatusCode = 200, msg = `SetCaseTeam is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam`, user, team);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param caseTeamUser
     */
    static setUser(user_1, caseId_1, caseTeamUser_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, caseTeamUser, expectedStatusCode = 200, msg = `SetCaseTeamUser(${caseTeamUser}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/users`, user, caseTeamUser);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param member
     */
    static removeUser(user_1, caseId_1, userId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, userId, expectedStatusCode = 200, msg = `RemoveCaseTeamUser(${userId}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/users/${userId}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param group
     */
    static setGroup(user_1, caseId_1, group_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, group, expectedStatusCode = 200, msg = `SetCaseTeamGroup(${group}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/groups`, user, group);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param group
     */
    static removeGroup(user_1, caseId_1, groupId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, groupId, expectedStatusCode = 200, msg = `RemoveCaseTeamGroup(${groupId}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/groups/${groupId}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static setTenantRole(user_1, caseId_1, tenantRole_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, tenantRole, expectedStatusCode = 200, msg = `SetCaseTeamTenantRole(${tenantRole}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/tenant-roles`, user, tenantRole);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static removeTenantRole(user_1, caseId_1, tenantRoleName_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, tenantRoleName, expectedStatusCode = 200, msg = `RemoveCaseTeamTenantRole(${tenantRoleName}) is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/tenant-roles/${tenantRoleName}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
}
exports.default = CaseTeamService;
