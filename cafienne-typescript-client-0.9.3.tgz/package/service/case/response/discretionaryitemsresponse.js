"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscretionaryItemsResponse = void 0;
const cmmnbaseclass_1 = __importDefault(require("../../../cmmn/cmmnbaseclass"));
/**
 * Simple JSON interface wrapper
 */
class DiscretionaryItemsResponse extends cmmnbaseclass_1.default {
    constructor(caseInstanceId, name, discretionaryItems) {
        super();
        this.caseInstanceId = caseInstanceId;
        this.name = name;
        this.discretionaryItems = discretionaryItems;
    }
}
exports.DiscretionaryItemsResponse = DiscretionaryItemsResponse;
