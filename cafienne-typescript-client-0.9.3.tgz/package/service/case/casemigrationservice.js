"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefinitionMigration = void 0;
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const trace_1 = __importDefault(require("../../infra/trace"));
class CaseMigrationService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static migrateDefinition(user_1, Case_1, migration_1) {
        return __awaiter(this, arguments, void 0, function* (user, Case, migration, expectedStatusCode = 200, msg = `MigrateDefinition is not expected to succeed for user ${user.id} in case ${Case.id}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${Case.id}/migrate-definition`, user, {
                newDefinition: migration.newDefinition.toString(),
                newTeam: migration.newTeam,
            });
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, undefined, trace);
        });
    }
}
exports.default = CaseMigrationService;
class DefinitionMigration {
    constructor(newDefinition, newTeam) {
        this.newDefinition = newDefinition;
        this.newTeam = newTeam;
    }
}
exports.DefinitionMigration = DefinitionMigration;
