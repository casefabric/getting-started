"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const userinformation_1 = __importDefault(require("../../tenant/userinformation"));
const config_1 = __importDefault(require("../../config"));
const response_1 = require("../response");
const logger_1 = __importDefault(require("../../logger"));
const trace_1 = __importDefault(require("../../infra/trace"));
/**
 * Connection to the /registration APIs of Cafienne
 */
class PlatformService {
    /**
     * Creates the tenant on behalf of the user. User must be a platform owner.
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static createTenant(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 204, errorMsg = `CreateTenant is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Creating Tenant ${tenant.name}`);
            const response = yield cafienneservice_1.default.post('/platform', user, tenant.toJson());
            if (response.status === 400 && expectedStatusCode === 204) {
                const msg = yield response.text();
                if (msg === 'Tenant already exists' || msg.indexOf('Failure while handling message CreateTenant') >= 0) {
                    // Tenant already exists is ok.
                    if (config_1.default.PlatformService.log)
                        logger_1.default.debug(`Tenant ${tenant.name} already exists.'`);
                    return response;
                }
            }
            return (0, response_1.checkResponse)(response, errorMsg, expectedStatusCode, trace);
        });
    }
    /**
     * Disable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static disableTenant(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 204, msg = `Disabling the tenant ${tenant} was not expected to succeed`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/platform/${tenant}/disable`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Enable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static enableTenant(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 204, msg = `Enabling the tenant ${tenant} was not expected to succeed`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/platform/${tenant}/enable`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    static getDisabledTenants(user_1) {
        return __awaiter(this, arguments, void 0, function* (user, expectedStatusCode = 200) {
            throw new Error('Not yet implemented in the server side');
        });
    }
    /**
     * Fetches all information the case engine has on this user.
     * Can only be invoked by the user itself.
     * @param user
     */
    static getUserInformation(user_1) {
        return __awaiter(this, arguments, void 0, function* (user, trace = new trace_1.default()) {
            const url = '/platform/user';
            const response = yield cafienneservice_1.default.get(url, user);
            return (0, response_1.checkJSONResponse)(response, 'Expected valid user information', 200, userinformation_1.default, trace);
        });
    }
    /**
     * Returns a json with the platform health
     */
    static getHealth() {
        return __awaiter(this, arguments, void 0, function* (trace = new trace_1.default()) {
            const url = '/health';
            const response = yield cafienneservice_1.default.get(url, undefined);
            return (0, response_1.checkJSONResponse)(response, 'Expected proper health information', 200, undefined, trace);
        });
    }
    /**
     * Returns a json with the platform version
     */
    static getVersion() {
        return __awaiter(this, arguments, void 0, function* (trace = new trace_1.default()) {
            const url = '/version';
            const response = yield cafienneservice_1.default.get(url, undefined);
            return (0, response_1.checkJSONResponse)(response, 'Expected proper version information', 200, undefined, trace);
        });
    }
}
exports.default = PlatformService;
