"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.printHeaders = printHeaders;
const isomorphic_fetch_1 = __importDefault(require("isomorphic-fetch"));
const config_1 = __importDefault(require("../config"));
const logger_1 = __importDefault(require("../logger"));
const queryfilter_1 = require("./queryfilter");
const response_1 = __importDefault(require("./response"));
class CafienneHeaders {
    constructor() {
        this.values = new Object();
    }
    setHeader(name, value) {
        this.values[name] = value;
    }
}
const BaseHeaders = new CafienneHeaders();
BaseHeaders.setHeader('Content-Type', 'application/json');
class CafienneService {
    /**
     * Returns base headers (copying case-last-modified and tenant-last-modified) and
     * sets a new bearer token based on the user's token
     * Optionally copies the additional headers from the "from" object
     * @param user
     * @param from
     */
    static getHeaders(user, from = {}) {
        return getHeaders(user, from);
    }
    static get baseURL() {
        return config_1.default.CafienneService.url;
    }
    static updateCaseLastModified(response) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: this currently is not a Singleton, but it should be...
            if (response.ok) {
                const readAndUpdateHeader = (headerName) => {
                    const headerValue = response.headers.get(headerName);
                    if (headerValue) {
                        if (config_1.default.CafienneService.log.response.headers) {
                            logger_1.default.debug(`Updating ${headerName} to ${headerValue}`);
                        }
                        BaseHeaders.setHeader(headerName, headerValue);
                    }
                };
                readAndUpdateHeader('Case-Last-Modified');
                readAndUpdateHeader('Tenant-Last-Modified');
                readAndUpdateHeader('Consent-Group-Last-Modified');
            }
            return response;
        });
    }
    static post(url_1, user_1, request_1) {
        return __awaiter(this, arguments, void 0, function* (url, user, request, method = 'POST') {
            const body = (typeof request === 'string') ? `"${request}"` : request ? JSON.stringify(request, undefined, 2) : undefined;
            return this.fetch(user, url, method, getHeaders(user), body);
        });
    }
    static postXML(url_1, user_1, request_1) {
        return __awaiter(this, arguments, void 0, function* (url, user, request, method = 'POST') {
            const headers = getHeaders(user, { 'Content-Type': 'application/xml' });
            const body = request.toString();
            return this.fetch(user, url, method, headers, body);
        });
    }
    static put(url, user, request) {
        return __awaiter(this, void 0, void 0, function* () {
            // Sorry, bit of a hack here...
            return this.post(url, user, request, 'PUT');
        });
    }
    static delete(url, user) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.fetch(user, url, 'DELETE');
        });
    }
    static patch(user, url) {
        return __awaiter(this, void 0, void 0, function* () {
            const headers = getHeaders(user);
            return this.fetch(user, url, 'PATCH', headers);
        });
    }
    static get(url, user, filter, headers) {
        return __awaiter(this, void 0, void 0, function* () {
            if (filter) {
                url = (0, queryfilter_1.extendURL)(url, filter);
            }
            return this.fetch(user, url, 'GET', headers);
        });
    }
    static getXml(url, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const headers = getHeaders(user, { 'Content-Type': 'text/xml' });
            return (yield this.get(url, user, undefined, headers)).xml();
        });
    }
    static fetch(user, url, method, headers, body) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!headers) {
                headers = getHeaders(user);
            }
            // Each time make sure we take the latest Authorization header from the user, or send no Authorization along
            url = this.baseURL + (url.startsWith('/') ? url.substring(1) : url);
            const myCallNumber = this.calls++;
            if (config_1.default.CafienneService.log.url) {
                logger_1.default.info(`\n\nHTTP:${method}[${myCallNumber}] from [${user ? user.id : ''}] to ${url}`);
            }
            if (config_1.default.CafienneService.log.request.headers) {
                printHeaders('Request headers:', headers);
            }
            if (config_1.default.CafienneService.log.request.body && body) {
                logger_1.default.debug(body);
            }
            const response = yield (0, isomorphic_fetch_1.default)(url, { method, headers, body }).then(response => new response_1.default(response)).then(this.updateCaseLastModified);
            if (!response.ok && config_1.default.CafienneService.log.response.error) {
                if (!config_1.default.CafienneService.log.url) {
                    logger_1.default.error(`\n\nHTTP:${method}[${myCallNumber}] from [${user ? user.id : ''}] to ${url}`);
                }
                // Print error responses in a different color
                if (config_1.default.CafienneService.log.request.headers || (config_1.default.CafienneService.log.request.body && body)) {
                    // Add an extra newline to show the response
                    logger_1.default.debug();
                }
                logger_1.default.error(`RESPONSE[${myCallNumber}]==> ${response.status} ${response.statusText}`);
                if (config_1.default.CafienneService.log.response.headers) {
                    printHeaders('Response headers:', response.headers);
                }
            }
            else {
                if (config_1.default.CafienneService.log.response.status) {
                    if (config_1.default.CafienneService.log.request.headers || (config_1.default.CafienneService.log.request.body && body)) {
                        // Add an extra newline to show the response
                        logger_1.default.debug();
                    }
                    logger_1.default.info(`RESPONSE[${myCallNumber}]==> ${response.status} ${response.statusText}`);
                }
                if (config_1.default.CafienneService.log.response.headers) {
                    printHeaders('Response headers:', response.headers);
                }
            }
            // Wait until full response text is arrived.
            const text = yield response.text();
            // For response ok, print to debug log only; for response not-ok print info logging
            if (!response.ok && config_1.default.CafienneService.log.response.error) {
                logger_1.default.error(text);
            }
            else if (config_1.default.CafienneService.log.response.body) {
                logger_1.default.debug(text);
            }
            return response;
        });
    }
}
CafienneService.calls = 0;
exports.default = CafienneService;
function printHeaders(msg, headers) {
    logger_1.default.debug(msg);
    if (headers.constructor.name === 'Headers') {
        headers.forEach((value, key) => {
            logger_1.default.debug(` ${key}\t: ${value}`);
        });
    }
    else {
        Object.entries(headers).forEach(([key, value]) => {
            logger_1.default.debug(` ${key}\t: ${value}`);
        });
    }
}
/**
 * Returns base headers for the user (optional)
 * along with new headers to copy "from"
 * @param user
 * @param from
 */
function getHeaders(user, from = {}) {
    const headers = {};
    // First, copy the base headers (to include Case-Last-Modified and Tenant-Last-Modified)
    for (const headerName in BaseHeaders.values) {
        const headerValue = BaseHeaders.values[headerName];
        headers[headerName] = headerValue;
    }
    // Now, remove and potentially renew the authorization header
    delete headers['Authorization'];
    if (user && user.token) {
        headers['Authorization'] = 'Bearer ' + user.token;
    }
    // Finally, check if there is anything additional to copy from
    for (const headerName in from) {
        const headerValue = from[headerName];
        if (headerValue && !(headerValue instanceof Function)) {
            headers[headerName] = headerValue;
        }
    }
    return headers;
}
