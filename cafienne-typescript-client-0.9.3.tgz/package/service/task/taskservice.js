"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const task_1 = __importDefault(require("../../cmmn/task"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
/**
 * Base class for invoking the Cafienne Tasks API (http://localhost:2027/tasks)
 */
class TaskService {
    /**
     * Claims the task on behalf of this user
     * @param task Task to claim
     * @param user User claiming the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static claimTask(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was claimed succesfully, but this was not expected`;
            }
            if (!msg) {
                msg = msg;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/claim`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Revokes the task on behalf of this user
     * @param task Task to revoke
     * @param user User revoking the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static revokeTask(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was revoked succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/revoke`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Assigns the task to the specified user
     * @param task Task to assign
     * @param user User assigning the task
     * @param assignee User to which the task is assigned
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static assignTask(user_1, task_2, assignee_1) {
        return __awaiter(this, arguments, void 0, function* (user, task, assignee, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was assigned successfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/assign`, user, { assignee: assignee.id });
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delegates the task on behalf of this user
     * @param task Task to delegate
     * @param user User delegating the task
     * @param assignee User to which the task is delegated
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static delegateTask(user_1, task_2, assignee_1) {
        return __awaiter(this, arguments, void 0, function* (user, task, assignee, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was delegated succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/delegate`, user, { assignee: assignee.id });
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Completes the task on behalf of the user, with the optional task output.
     * @param task
     * @param user
     * @param taskOutput
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static completeTask(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, taskOutput = {}, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was completed succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.post(`tasks/${taskId}/complete`, user, taskOutput);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Validates whether the given output is acceptable for the task.
     * @param task Task to validate output against
     * @param user User trying to validate the task output
     * @param taskOutput Task output to validate
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static validateTaskOutput(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, taskOutput = {}, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task output for '${taskName}' with id ${taskId} was validated succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.post(`tasks/${taskId}`, user, taskOutput);
            const res = yield (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
            if (response.ok) {
                const json = yield response.json();
                return json;
            }
            else {
                const text = yield response.text();
                return text;
            }
        });
    }
    /**
     * Save the task output on behalf of the user
     * @param task Task to save the output in
     * @param user User saving the task output
     * @param taskOutput Task output to save
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static saveTaskOutput(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, taskOutput = {}, expectedStatusCode = 202, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task output for '${taskName}' with id ${taskId} was saved succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}`, user, taskOutput);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Fetches and refreshes the task information from the backend
     * Note: returns a fresh instance of Task
     * @param task
     * @param user
     */
    static getTask(user_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, task, expectedStatusCode = 200, msg = '', trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            if (!msg) {
                msg = `GetTask is not expected to succeed for user ${user} on task ${taskId}`;
            }
            const response = yield cafienneservice_1.default.get(`tasks/${taskId}`, user);
            return yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, task_1.default, trace);
        });
    }
    /**
     * Fetches all tasks from the specified case instance from the backend
     * @param Case
     * @param user
     */
    static getCaseTasks(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `GetCaseTasks is not expected to succeed for member ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/tasks/case/${caseId}`, user);
            return yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [task_1.default], trace);
        });
    }
    /**
     * Fetches all tasks from the specified case instance from the backend and searches within that list for the one that
     * matches the task parameter (either task id or task name can be given).
     * @param Case
     * @param user
     * @param task
     */
    static getCaseTask(user_1, caseId_1, task_2) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, task, trace = new trace_1.default()) {
            const taskId = getTaskId(task);
            const tasks = yield this.getCaseTasks(user, caseId, undefined, undefined, trace);
            const responseTask = tasks.find(task => task.id === taskId || task.taskName === taskId);
            if (!responseTask) {
                throw new asyncerror_1.default(trace, `Cannot find task ${taskId} in case ${caseId}; tasks are ${tasks.map(t => t.taskName).join('\'')}`);
            }
            else {
                return responseTask;
            }
        });
    }
    /**
     * Returns all tasks from case instances with the specified definition
     * @param user
     * @param definition
     */
    static getTasksOfCaseType(user_1, definition_1) {
        return __awaiter(this, arguments, void 0, function* (user, definition, expectedStatusCode = 200) {
            throw new Error('Not yet implemented');
        });
    }
    /**
     * Fetches all tasks to which the user has access, with an optional filter
     * @param user User fetching the task list
     * @param filter Optional filter for the tasks (e.g., to get only Active tasks)
     */
    static getTasks(user_1, filter_1) {
        return __awaiter(this, arguments, void 0, function* (user, filter, expectedStatusCode = 200, msg = `GetTasks is not expected to succeed for member ${user}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get('/tasks', user, filter);
            return yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [task_1.default], trace);
        });
    }
    /**
     * Counts the number of tasks that the user has access to.
     * Returns the count of assigned and unassigned tasks.
     * @param user
     * @param filter
     */
    static countTasks(user_1, filter_1) {
        return __awaiter(this, arguments, void 0, function* (user, filter, expectedStatusCode = 200, msg = `CountTasks is not expected to succeed for member ${user}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get('/tasks/user/count', user, filter);
            return yield (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, undefined, trace);
        });
    }
}
exports.default = TaskService;
function getTaskId(task) {
    return (typeof (task) === 'string') ? task : task.id;
}
function getTaskName(task) {
    return (typeof (task) === 'string') ? task : task instanceof task_1.default ? task.taskName : task.name;
}
