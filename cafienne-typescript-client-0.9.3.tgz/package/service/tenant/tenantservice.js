"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const tenantuser_1 = __importDefault(require("../../tenant/tenantuser"));
const response_1 = require("../response");
const trace_1 = __importDefault(require("../../infra/trace"));
/**
 * Connection to the /tenant APIs of Cafienne
 */
class TenantService {
    /**
     * Return a list of the current owners of the tenant. Can only be invoked by users that are owner of the tenant.
     * @param user Must be a tenant owner
     * @param tenant
     * @param expectedStatusCode
     */
    static getTenantOwners(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 200, msg = `GetTenantOwners is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/tenant/${tenant}/owners`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, undefined, trace);
        });
    }
    /**
     * Returns a list of the tenant users
     * @param user Must be a valid user in the tenant
     * @param tenant
     * @param expectedStatusCode
     */
    static getTenantUsers(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 200, msg = `GetTenantUsers is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/tenant/${tenant}/users`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [tenantuser_1.default], trace);
        });
    }
    /**
     * Returns a list of the tenant users
     * @param user Must be a valid user in the tenant
     * @param tenant
     * @param expectedStatusCode
     */
    static getDisabledUserAccounts(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 200, msg = `GettingDisabledAccounts is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/tenant/${tenant}/disabled-accounts`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [tenantuser_1.default], trace);
        });
    }
    /**
     * Retrieve information about a specific tenant user
     * @param user Must be a tenant user
     * @param tenant
     * @param tenantUserId
     * @param expectedStatusCode
     */
    static getTenantUser(user_1, tenant_1, tenantUserId_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, tenantUserId, expectedStatusCode = 200, msg = `GetTenantUser(${tenantUserId}) is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/tenant/${tenant}/users/${tenantUserId}`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, tenantuser_1.default, trace);
        });
    }
    /**
     * Adds or replaces the tenant user
     * @param user Must be a tenant owner
     * @param tenant
     * @param newTenantUser
     * @param expectedStatusCode
     */
    static setTenantUser(user_1, tenant_1, newTenantUser_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, newTenantUser, expectedStatusCode = 204, msg = `SetTenantUser is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const userToSet = newTenantUser.toJson ? newTenantUser.toJson() : newTenantUser;
            const response = yield cafienneservice_1.default.post(`/tenant/${tenant}/users`, user, userToSet);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Remove the user from the tenant
     * @param user Must be a tenant owner
     * @param tenant
     * @param newTenantUser
     * @param expectedStatusCode
     */
    static removeTenantUser(user_1, tenant_1, tenantUser_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, tenantUser, expectedStatusCode = 204, msg = `RemoveTenantUser is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/tenant/${tenant}/users/${tenantUser}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Replaces the tenant users (in one API call, bulk replace)
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static replaceTenant(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, expectedStatusCode = 204, msg = `ReplaceTenant is not expected to succeed for user ${user} in tenant ${tenant}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/tenant/${tenant}`, user, tenant.toJson());
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
}
exports.default = TenantService;
