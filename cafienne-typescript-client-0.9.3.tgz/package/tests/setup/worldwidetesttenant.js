"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = __importDefault(require("../../user"));
const tenantuser_1 = __importStar(require("../../tenant/tenantuser"));
const tenant_1 = __importDefault(require("../../tenant/tenant"));
const platformservice_1 = __importDefault(require("../../service/platform/platformservice"));
const tenantservice_1 = __importDefault(require("../../service/tenant/tenantservice"));
/**
 * Simple test tenant to avoid duplicate code
 */
class WorldWideTestTenant {
    get sender() {
        return this.wrapper.sender;
    }
    get receiver() {
        return this.wrapper.receiver;
    }
    get employee() {
        return this.wrapper.employee;
    }
    get tenant() {
        return this.wrapper.tenant;
    }
    constructor(name = WorldWideTestTenant.defaultTenantName, platformAdmin = new user_1.default('admin')) {
        this.name = name;
        this.platformAdmin = platformAdmin;
        this.wrapper = TenantWrapper.get(name, platformAdmin);
    }
    /**
     * Creates the tenant, and logs in for sender user and receiver user.
     */
    create() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.wrapper.create();
        });
    }
    /**
     * Resets and clears any cached information on the creation of this tenant.
     * This is typically invoked from the StorageService upon successfull tenant deletion.
     * @param tenant
     */
    static reset(tenant) {
        TenantWrapper.reset(tenant);
    }
}
//*/
WorldWideTestTenant.defaultTenantName = 'World-Wide-Test-Tenant';
exports.default = WorldWideTestTenant;
class TenantWrapper {
    static get(name, platformAdmin) {
        const existingWrapper = this.wrappers.find(wrapper => wrapper.name === name);
        if (existingWrapper) {
            return existingWrapper;
        }
        else {
            const newWrapper = new TenantWrapper(name, platformAdmin);
            this.wrappers.push(newWrapper);
            return newWrapper;
        }
    }
    static reset(tenant) {
        const existingWrapper = this.wrappers.find(wrapper => wrapper.name === '' + tenant);
        if (existingWrapper) {
            existingWrapper.resetCreationState();
        }
    }
    get senderId() {
        if (this.name === 'world') {
            return 'CgRzdXp5EgVsb2NhbA'; // suzy
        }
        return 'sending-user';
    }
    get receiverId() {
        if (this.name === 'world') {
            return 'CgRsYW5hEgVsb2NhbA'; // lana
        }
        return 'receiving-user';
    }
    get employeeId() {
        if (this.name === 'world') {
            return 'CgRoYW5rEgVsb2NhbA'; // hank
        }
        return 'employee';
    }
    constructor(name, platformAdmin) {
        this.name = name;
        this.platformAdmin = platformAdmin;
        this.sender = new tenantuser_1.TenantOwner(this.senderId, ['Sender'], 'sender', 'sender@senders.com');
        this.receiver = new tenantuser_1.TenantOwner(this.receiverId, ['Receiver'], 'receiver', 'receiver@receivers.com');
        this.employee = new tenantuser_1.default(this.employeeId, ['Employee'], 'another employee', 'without any email address');
        this.tenant = new tenant_1.default(this.name, [this.sender, this.receiver, this.employee]);
        this.created = false;
        this.creating = false;
        this.waiters = [];
    }
    resetCreationState() {
        this.created = false;
        this.creating = false;
    }
    /**
     * Creates the tenant, and logs in for sender user and receiver user.
     */
    create() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.created) {
                if (!this.sender.token) {
                    yield this.sender.login();
                }
                yield tenantservice_1.default.getTenantOwners(this.sender, this.tenant);
            }
            else if (this.creating) {
                // Start waiting until the other calls are done
                yield new Promise((resolve, reject) => this.waiters.push(resolve));
            }
            else {
                this.creating = true;
                yield this.platformAdmin.login();
                yield platformservice_1.default.createTenant(this.platformAdmin, this.tenant);
                yield this.sender.login();
                yield this.receiver.login();
                yield this.employee.login();
                this.created = true;
                this.waiters.forEach(waiter => waiter());
            }
        });
    }
}
TenantWrapper.wrappers = [];
