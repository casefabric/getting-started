"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("./config"));
class logger {
    static endGroup() {
        console.groupEnd();
    }
    static debug(msg = '') {
        if (this.debugEnabled) {
            coloredPrinter(config_1.default.Log.color.debug, 'DEBUG', msg);
        }
    }
    static info(msg = '', startGroup = false) {
        if (this.infoEnabled) {
            coloredPrinter(config_1.default.Log.color.info, 'INFO', msg);
        }
    }
    static warn(msg = '') {
        if (this.warnEnabled) {
            coloredPrinter(config_1.default.Log.color.warn, 'WARN', msg);
        }
    }
    static error(msg = '') {
        if (this.errorEnabled) {
            coloredPrinter(config_1.default.Log.color.error, 'ERROR', msg);
        }
    }
    static get debugEnabled() {
        return config_1.default.Log.level.toLowerCase() === 'debug';
    }
    static get infoEnabled() {
        return this.debugEnabled || config_1.default.Log.level.toLowerCase() === 'info';
    }
    static get warnEnabled() {
        return this.infoEnabled || config_1.default.Log.level.toLowerCase() === 'warn';
    }
    static get errorEnabled() {
        return this.warnEnabled || config_1.default.Log.level.toLowerCase() === 'error';
    }
}
exports.default = logger;
function coloredPrinter(color, prefix, msg, startGroup = false) {
    while (msg.startsWith('\n')) {
        console.log();
        msg = msg.substring(1);
    }
    if (startGroup) {
        console.group(color, msg);
    }
    else {
        console.log(color, msg);
    }
}
