"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const asyncerror_1 = __importDefault(require("./asyncerror"));
class StackTraceError extends Error {
    constructor(error, prefix = '', postfix = '') {
        super(prefix + printStackTrace(error) + postfix);
    }
}
exports.default = StackTraceError;
function printStackTrace(error) {
    if (error instanceof asyncerror_1.default) {
        return error.message;
    }
    else if (error instanceof Error) {
        return error.stack ? error.stack.split('\n').join('\n') : `${error.constructor.name}: ${error.message}`;
    }
    else if (error instanceof Object) {
        return `${error.constructor.name}: ${error}`;
    }
    else {
        return `${error}`;
    }
}
