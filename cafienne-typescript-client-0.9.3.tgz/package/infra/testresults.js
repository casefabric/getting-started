"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class TestResults {
    constructor() {
        this.list = [];
    }
    addTest(result) {
        this.list.push(result);
    }
    toString() {
        return this.list.map((test, index) => ` ${index < 9 ? '0' + (index + 1) : index + 1} - ${test}\n`).join('');
    }
}
exports.default = TestResults;
