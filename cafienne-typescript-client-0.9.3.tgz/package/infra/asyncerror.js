"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AsyncError extends Error {
    constructor(trace, msg = '') {
        super(trace.toMessage(msg));
    }
}
exports.default = AsyncError;
