"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const stacktraceerror_1 = __importDefault(require("./stacktraceerror"));
class TestRunner {
    constructor(testClass, isExplicitlyMentionedTest = false) {
        this.testClass = testClass;
        this.isExplicitlyMentionedTest = isExplicitlyMentionedTest;
        this.name = this.testClass.name;
        this.calculatedWhitespace = '                                         '.substring(this.name.length);
        this.started = new Date();
        this.ended = new Date();
        this.summary = '';
        this.error = undefined;
        this.testNumber = 0;
        this.running = false;
        this.completed = false;
        try {
            const constructor = this.testClass;
            this.test = new constructor();
        }
        catch (e) {
            throw new stacktraceerror_1.default(e, `Unknown failure while running constructor of ${this.name}:\n`);
        }
    }
    needsRunning() {
        return this.isExplicitlyMentionedTest || this.test.isDefaultTest;
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            this.calculatedWhitespace = '                                          '.substring((this.name + this.testNumber).length);
            try {
                yield this.prepare();
                yield this.run();
                yield this.close();
            }
            catch (error) {
                this.failed(error);
            }
        });
    }
    prepare() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`\n
######################################################################
#                                                                    #
#      PREPARING TEST ${this.testNumber}:  "${this.name}"${this.calculatedWhitespace}#
#                                                                    #
######################################################################
                        `);
            yield this.test.onPrepareTest();
        });
    }
    run() {
        return __awaiter(this, void 0, void 0, function* () {
            this.running = true;
            this.started = new Date();
            console.log(`\n
######################################################################
#                                                                    #
#      STARTING TEST ${this.testNumber}:   "${this.name}"${this.calculatedWhitespace}#
#                                                                    #
######################################################################
                        `);
            yield this.test.run();
        });
    }
    close() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`\n
######################################################################
#                                                                    #
#      CLOSING TEST ${this.testNumber}:    "${this.name}"${this.calculatedWhitespace}#
#                                                                    #
######################################################################
                        `);
            yield this.test.onCloseTest();
            this.finished();
        });
    }
    finished() {
        this.ended = new Date();
        this.completed = true;
        if (this.test.identifiers.length) {
            this.summary = `  ---  [ ${this.test.identifiers.join(' | ')} ]`;
        }
        this.ended = new Date();
    }
    failed(error) {
        this.ended = new Date();
        this.error = error;
        if (this.test.identifiers.length) {
            this.summary = `  ---  [ ${this.test.identifiers.join(' | ')} ]`;
        }
        this.ended = new Date();
    }
    toString() {
        return this.report();
    }
    report() {
        const indexString = `${this.testNumber < 0 ? '0' : ''}${this.testNumber}`;
        if (this.error) {
            return ` ${indexString} - ${this.name} ${this.summary} failed after ${(this.ended.getTime() - this.started.getTime())} ms`;
        }
        else {
            return ` ${indexString} - ${this.name} (${(this.ended.getTime() - this.started.getTime())} ms) ${this.summary}`;
        }
    }
}
exports.default = TestRunner;
