"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mockurl_1 = __importDefault(require("./mockurl"));
class PostMock extends mockurl_1.default {
    addRoute() {
        this.mockServer.express.post(this.url, (req, res, next) => this.handleRoute(req, res, next));
    }
}
exports.default = PostMock;
