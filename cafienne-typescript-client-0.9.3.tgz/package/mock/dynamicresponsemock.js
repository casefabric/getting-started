"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mockserver_1 = __importDefault(require("./mockserver"));
const postmock_1 = __importDefault(require("./postmock"));
class DynamicResponseMock extends mockserver_1.default {
    constructor(port) {
        super(port);
        this.mock = new postmock_1.default(this, '/get/code/:code', call => {
            const code = Number(call.req.params['code']);
            call.onContent((body) => {
                console.log(`Returning ${code} with ${body}`);
                call.res.status(code).write(body);
                call.res.end();
            });
        });
    }
}
exports.default = DynamicResponseMock;
