"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CaseEvent {
}
CaseEvent.TaskInputFilled = 'TaskInputFilled';
CaseEvent.HumanTaskActivated = 'HumanTaskActivated';
CaseEvent.HumanTaskInputSaved = 'HumanTaskInputSaved';
CaseEvent.CaseModified = 'CaseModified';
CaseEvent.DebugEvent = 'DebugEvent';
CaseEvent.PlanItemCreated = 'PlanItemCreated';
CaseEvent.PlanItemTransitioned = 'PlanItemTransitioned';
CaseEvent.RepetitionRuleEvaluated = 'RepetitionRuleEvaluated';
CaseEvent.RequiredRuleEvaluated = 'RequiredRuleEvaluated';
CaseEvent.CaseDefinitionMigrated = 'CaseDefinitionMigrated';
CaseEvent.PlanItemMigrated = 'PlanItemMigrated';
CaseEvent.PlanItemDropped = 'PlanItemDropped';
CaseEvent.HumanTaskDropped = 'HumanTaskDropped';
exports.default = CaseEvent;
