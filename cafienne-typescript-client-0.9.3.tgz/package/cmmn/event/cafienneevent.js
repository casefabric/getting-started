"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CafienneEvent {
    constructor(type, offset, content) {
        this.type = type;
        this.offset = offset;
        this.content = content;
    }
    toString() {
        if (this.type && this.type.indexOf('Migrated') >= 0 || this.type.indexOf('Dropped') >= 0 || this.type.indexOf('Created') >= 0) {
            if (this.type.indexOf('PlanItem') >= 0 || this.type.indexOf('HumanTask') >= 0) {
                return `${this.type}: ${this.content.path}`;
            }
            else if (this.type.indexOf('CaseDefinitionMigrated') >= 0) {
                return `${this.type} to ${this.content.caseName}`;
            }
        }
        else if (this.type.indexOf('Transitioned') >= 0) {
            return `${this.type} - ${this.content.type}[${this.path}]: ${this.content.historyState} ==> ${this.content.transition.toLowerCase()} ==> ${this.content.currentState}`;
        }
        else if (this.type.indexOf('Modified') >= 0) {
            return this.type + "\n";
        }
        else {
            return this.type;
        }
    }
    hasType(type) {
        return this.type === type;
    }
    get name() {
        return this.path.split('/').reverse()[0];
    }
    get path() {
        return this.content.path;
    }
}
exports.default = CafienneEvent;
