"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("../cmmnbaseclass"));
class CaseTeamTenantRole extends cmmnbaseclass_1.default {
    /**
     * Create a case team member linking to a tenant role
     * @param tenantRole Either a String or a User, holding the user id of the case team member
     * @param caseRoles Set of roles that the user has within this case team; if not given, then the roles of the user are used (if any)
     */
    constructor(tenantRole, caseRoles = []) {
        super();
        this.tenantRole = tenantRole;
        this.caseRoles = caseRoles;
        this.isOwner = undefined;
    }
    toString() {
        return this.tenantRole;
    }
}
exports.default = CaseTeamTenantRole;
