"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Base class for classes in this folder.
 * Has a default toString that prints the instance in pretty printed json format
 */
class CMMNBaseClass {
    toString() {
        return JSON.stringify(this, undefined, 2);
    }
}
exports.default = CMMNBaseClass;
