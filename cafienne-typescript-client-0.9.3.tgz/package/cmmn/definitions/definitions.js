"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const trace_1 = __importDefault(require("../../infra/trace"));
const repositoryservice_1 = __importDefault(require("../../service/case/repositoryservice"));
class Definitions {
    constructor(file) {
        this.file = file;
        this.isDeployed = false;
    }
    toString() {
        return this.file;
    }
    deploy(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, trace = new trace_1.default()) {
            if (!this.isDeployed) {
                yield repositoryservice_1.default.validateAndDeploy(user, this.file, tenant, trace);
            }
            this.isDeployed = true;
        });
    }
}
Definitions.BootstrapCaseFileEvents = new Definitions('bootstrap-casefile-events.xml');
Definitions.Calculation = new Definitions('calculation.xml');
Definitions.CaseFile = new Definitions('casefile.xml');
Definitions.CaseTeam = new Definitions('caseteam.xml');
Definitions.CaseWithSpace = new Definitions('casemetspatie.xml');
Definitions.Compatibility = new Definitions('compatibility.xml');
Definitions.ComplexCase = new Definitions('complexcase.xml');
Definitions.Documentation = new Definitions('documentation_case.xml');
Definitions.DynamicTaskModel = new Definitions('dynamictaskmodel.xml');
Definitions.EntryCriteriaOnCaseInputParameters = new Definitions('entrycriteriaoncaseinputparameters.xml');
Definitions.EntryCriteriaOnRecovery = new Definitions('entrycriteriaonrecovery.xml');
Definitions.EventListener = new Definitions('eventlistener.xml');
Definitions.Expressions = new Definitions('expressions.xml');
Definitions.FaultHandlingParentCase = new Definitions('faulthandling.xml');
Definitions.FaultHandlingSubCase = new Definitions('faulthandling_subcase.xml');
Definitions.FaultHandlingWithEntryCriterion = new Definitions('faulthandling_with_entrycriterion.xml');
Definitions.FootballClubStats = new Definitions('footballclubstats.xml');
Definitions.FootballStats = new Definitions('footballstats.xml');
Definitions.FourEyes = new Definitions('four_eyes.xml');
Definitions.GetListGetDetails = new Definitions('getlist_getdetails.xml');
Definitions.InvokeCafienne = new Definitions('invokecafienne.xml');
Definitions.HelloWorld = new Definitions('helloworld.xml');
Definitions.HelloWorld2 = new Definitions('helloworld2.xml');
Definitions.IncidentManagementForTraining = new Definitions('IncidentManagementForTraining.xml');
Definitions.Migration_GetList = new Definitions('migration/getlist.xml');
Definitions.Migration_GetList_v1 = new Definitions('migration/getlist_v1.xml');
Definitions.Migration_v0 = new Definitions('migration/migration_v0.xml');
Definitions.Migration_v1 = new Definitions('migration/migration_v1.xml');
Definitions.Migration_HelloworldBase = new Definitions('helloworld_base.xml');
Definitions.Migration_HelloworldMigrated = new Definitions('helloworld_migrated.xml');
Definitions.Migration_RepeatingTask_v0 = new Definitions('migration/repeating_task_v0.xml');
Definitions.Migration_RepeatingTask_v1 = new Definitions('migration/repeating_task_v1.xml');
Definitions.Migration_Discretionary_v0 = new Definitions('migration/discretionary_v0.xml');
Definitions.Migration_Discretionary_v1 = new Definitions('migration/discretionary_v1.xml');
Definitions.Planning = new Definitions('planning.xml');
Definitions.ProcessTaskTest = new Definitions('processtasktest.xml');
Definitions.RepeatStageTest = new Definitions('repeatstagetest.xml');
Definitions.RepeatWithMapping = new Definitions('repeat_with_mapping.xml');
Definitions.SMTPTest = new Definitions('smtptest.xml');
Definitions.SendMail = new Definitions('sendmail.xml');
Definitions.StageTaskExpressions = new Definitions('stagetaskexpressions.xml');
Definitions.StageTest = new Definitions('stagetest.xml');
Definitions.SubCaseTest = new Definitions('subcasetest.xml');
Definitions.SubCaseWithArrayOutput = new Definitions('subcasewitharrayoutput.xml');
Definitions.TaskBindingRefinement = new Definitions('taskbindingrefinement.xml');
Definitions.TaskOutputOperations = new Definitions('taskoutputoperations.xml');
Definitions.TaskOutputValidation = new Definitions('taskoutputvalidation.xml');
Definitions.Timer = new Definitions('timer.xml');
Definitions.TravelRequest = new Definitions('travelrequest.xml');
exports.default = Definitions;
