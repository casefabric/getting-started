"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantOwner = void 0;
const consentgroupmember_1 = __importStar(require("../service/consentgroup/consentgroupmember"));
const user_1 = __importDefault(require("../user"));
class TenantUser extends user_1.default {
    /**
     * Simple wrapper for a TenantUser object.
     * It needs a userId, which must match the 'sub' inside the JWT token sent to the case engine.
     * The class User has an id, and this id is put inside the 'sub' of the token when the user logs in.
     *
     * @param userId Typically filled from User.id.
     * @param roles Set of strings containing the names of the roles the user has within the tenant.
     * @param name Optional name for the user inside the tenant.
     * @param email Optional email for the user inside the tenant.
     * @param isOwner Optional flag to indicate that this user is a tenant owner
     * @param enabled Optional flag to indicate that the user account must be enabled/disabled
     * @param tenant Optional tenant name; is returned in server responses and can be used in expressions
     */
    constructor(userId, roles = [], name, email, isOwner = false, enabled = true) {
        super(userId);
        this.userId = userId;
        this.roles = roles;
        this.name = name;
        this.email = email;
        this.isOwner = isOwner;
        this.enabled = enabled;
    }
    toJson() {
        const userId = this.userId;
        const roles = this.roles;
        const name = this.name;
        const email = this.email;
        const isOwner = this.isOwner;
        const enabled = this.enabled;
        return { userId, roles, name, email, isOwner, enabled };
    }
    /**
     * Creates a new ConsentGroupMember object with the given roles.
     * The ConsentGroupMember will get the user id of this user.
     * @param roles
     */
    asCGM(...roles) {
        return new consentgroupmember_1.default(this.id, roles);
    }
    /**
     * Creates a new ConsentGroupOwner object with the given roles.
     * The ConsentGroupMember will get the user id of this user.
     * @param roles
     */
    asCGO(...roles) {
        return new consentgroupmember_1.ConsentGroupOwner(this.id, roles);
    }
}
exports.default = TenantUser;
class TenantOwner extends TenantUser {
    constructor(userId, roles = [], name, email, enabled = true) {
        super(userId, roles, name, email, true, enabled);
        this.userId = userId;
        this.roles = roles;
        this.name = name;
        this.email = email;
        this.enabled = enabled;
    }
}
exports.TenantOwner = TenantOwner;
